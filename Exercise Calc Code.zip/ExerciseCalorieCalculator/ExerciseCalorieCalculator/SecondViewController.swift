import UIKit

var userExerciseTime: Double?
var userHeartRate: Double?

class SecondViewController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        exerciseTime.delegate = self
        avgHeartRate.delegate = self
    }

    // MARK: - UI Elements (mirrors @IBOutlet connections from book)

    let titleLabel: UILabel = {
        let l = UILabel()
        l.text = "Enter exercise info"
        l.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        l.textColor = .systemBlue
        l.textAlignment = .center
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    let exerciseTimeLabel: UILabel = {
        let l = UILabel()
        l.text = "Exercise time:"
        l.font = UIFont.systemFont(ofSize: 17)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    var exerciseTime: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Enter your exercise time here"
        tf.borderStyle = .roundedRect
        tf.keyboardType = .decimalPad
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()

    let heartRateLabel: UILabel = {
        let l = UILabel()
        l.text = "Avg. heart rate:"
        l.font = UIFont.systemFont(ofSize: 17)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    var avgHeartRate: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Enter your average heart rate here"
        tf.borderStyle = .roundedRect
        tf.keyboardType = .numberPad
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()

    let saveButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("Save", for: .normal)
        b.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    // MARK: - Setup

    func setupUI() {
        view.addSubview(titleLabel)
        view.addSubview(exerciseTimeLabel)
        view.addSubview(exerciseTime)
        view.addSubview(heartRateLabel)
        view.addSubview(avgHeartRate)
        view.addSubview(saveButton)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            exerciseTimeLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 40),
            exerciseTimeLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            exerciseTime.centerYAnchor.constraint(equalTo: exerciseTimeLabel.centerYAnchor),
            exerciseTime.leadingAnchor.constraint(equalTo: exerciseTimeLabel.trailingAnchor, constant: 12),
            exerciseTime.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            exerciseTime.heightAnchor.constraint(equalToConstant: 36),

            heartRateLabel.topAnchor.constraint(equalTo: exerciseTimeLabel.bottomAnchor, constant: 24),
            heartRateLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            avgHeartRate.centerYAnchor.constraint(equalTo: heartRateLabel.centerYAnchor),
            avgHeartRate.leadingAnchor.constraint(equalTo: heartRateLabel.trailingAnchor, constant: 12),
            avgHeartRate.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            avgHeartRate.heightAnchor.constraint(equalToConstant: 36),

            saveButton.topAnchor.constraint(equalTo: heartRateLabel.bottomAnchor, constant: 32),
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        saveButton.addTarget(self, action: #selector(saveExerciseInfo(_:)), for: .touchUpInside)
    }

    // MARK: - Actions (mirrors @IBAction from book Code 8.6 / 8.9)

    @objc func saveExerciseInfo(_ sender: Any) {
        userExerciseTime = Double(exerciseTime.text!)
        userHeartRate = Double(avgHeartRate.text!)
    }

    // MARK: - UITextFieldDelegate (book Code 8.9 - keyboard dismiss)

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.exerciseTime.resignFirstResponder()
        self.avgHeartRate.resignFirstResponder()
        return true
    }
}
