import UIKit

var userAge: Double?
var userWeight: Double?
var userGender: String = "Female"

class FirstViewController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        yourAge.delegate = self
        yourWeight.delegate = self
    }

    // MARK: - UI Elements (mirrors @IBOutlet connections from book)

    let titleLabel: UILabel = {
        let l = UILabel()
        l.text = "Enter personal info"
        l.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        l.textColor = .systemBlue
        l.textAlignment = .center
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    let ageLabel: UILabel = {
        let l = UILabel()
        l.text = "Your age:"
        l.font = UIFont.systemFont(ofSize: 17)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    var yourAge: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Enter your age here"
        tf.borderStyle = .roundedRect
        tf.keyboardType = .numberPad
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()

    let weightLabel: UILabel = {
        let l = UILabel()
        l.text = "Your weight:"
        l.font = UIFont.systemFont(ofSize: 17)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    var yourWeight: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Enter your weight here"
        tf.borderStyle = .roundedRect
        tf.keyboardType = .decimalPad
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()

    var segmentedControl: UISegmentedControl = {
        let sc = UISegmentedControl(items: ["Female", "Male"])
        sc.selectedSegmentIndex = 0
        sc.translatesAutoresizingMaskIntoConstraints = false
        return sc
    }()

    let saveButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("Save", for: .normal)
        b.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    // MARK: - Setup

    func setupUI() {
        view.addSubview(titleLabel)
        view.addSubview(ageLabel)
        view.addSubview(yourAge)
        view.addSubview(weightLabel)
        view.addSubview(yourWeight)
        view.addSubview(segmentedControl)
        view.addSubview(saveButton)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            ageLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 40),
            ageLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            yourAge.centerYAnchor.constraint(equalTo: ageLabel.centerYAnchor),
            yourAge.leadingAnchor.constraint(equalTo: ageLabel.trailingAnchor, constant: 12),
            yourAge.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            yourAge.heightAnchor.constraint(equalToConstant: 36),

            weightLabel.topAnchor.constraint(equalTo: ageLabel.bottomAnchor, constant: 24),
            weightLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            yourWeight.centerYAnchor.constraint(equalTo: weightLabel.centerYAnchor),
            yourWeight.leadingAnchor.constraint(equalTo: weightLabel.trailingAnchor, constant: 12),
            yourWeight.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            yourWeight.heightAnchor.constraint(equalToConstant: 36),

            segmentedControl.topAnchor.constraint(equalTo: weightLabel.bottomAnchor, constant: 32),
            segmentedControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            segmentedControl.widthAnchor.constraint(equalToConstant: 200),

            saveButton.topAnchor.constraint(equalTo: segmentedControl.bottomAnchor, constant: 32),
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        segmentedControl.addTarget(self, action: #selector(genderButton(_:)), for: .valueChanged)
        saveButton.addTarget(self, action: #selector(savePersonalInfo(_:)), for: .touchUpInside)
    }

    // MARK: - Actions (mirrors @IBAction from book Code 8.5 / 8.8)

    @objc func genderButton(_ sender: Any) {
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            userGender = "Female"
        case 1:
            userGender = "Male"
        default:
            return
        }
    }

    @objc func savePersonalInfo(_ sender: Any) {
        userWeight = Double(yourWeight.text!)
        userAge = Double(yourAge.text!)
    }

    // MARK: - UITextFieldDelegate (book Code 8.8 - keyboard dismiss)

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.yourWeight.resignFirstResponder()
        self.yourAge.resignFirstResponder()
        return true
    }
}
