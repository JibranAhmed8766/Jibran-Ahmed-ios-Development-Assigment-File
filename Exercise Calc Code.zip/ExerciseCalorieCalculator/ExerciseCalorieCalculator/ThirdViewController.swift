import UIKit

var caloriesBurned: Double?

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
    }

    // MARK: - UI Elements (mirrors @IBOutlet from book Code 8.4)

    var calories: UILabel = {
        let l = UILabel()
        l.text = "... calories burned"
        l.font = UIFont.systemFont(ofSize: 17)
        l.textAlignment = .center
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    let calculateButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("Click to calculate!", for: .normal)
        b.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    // MARK: - Setup

    func setupUI() {
        view.addSubview(calculateButton)
        view.addSubview(calories)

        NSLayoutConstraint.activate([
            calculateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            calculateButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -20),

            calories.topAnchor.constraint(equalTo: calculateButton.bottomAnchor, constant: 20),
            calories.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            calories.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])

        calculateButton.addTarget(self, action: #selector(calcCalories(_:)), for: .touchUpInside)
    }

    // MARK: - Action (mirrors @IBAction calcCalories from book Code 8.7)

    @objc func calcCalories(_ sender: Any) {
        switch userGender {
        case "Female":
            caloriesBurned = ((userAge! * 0.074) -
                (userWeight! * 0.05741) +
                (userHeartRate! * 0.4472) -
                20.4022) * userExerciseTime! / 4.184
        case "Male":
            caloriesBurned = ((userAge! * 0.2017) -
                (userWeight! * 0.09036) +
                (userHeartRate! * 0.6309) -
                55.0969) * userExerciseTime! / 4.184
        default:
            return
        }
        calories.text = String(Int(caloriesBurned!)) + " calories burned"
    }
}
