import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        window = UIWindow(windowScene: windowScene)

        let tabBarController = UITabBarController()

        let firstVC = FirstViewController()
        firstVC.tabBarItem = UITabBarItem(title: "Enter personal info", image: UIImage(systemName: "circle.fill"), tag: 0)

        let secondVC = SecondViewController()
        secondVC.tabBarItem = UITabBarItem(title: "Enter exercise info", image: UIImage(systemName: "square.fill"), tag: 1)

        let thirdVC = ThirdViewController()
        thirdVC.tabBarItem = UITabBarItem(title: "Calculate calories", image: UIImage(systemName: "circle.fill"), tag: 2)

        tabBarController.viewControllers = [firstVC, secondVC, thirdVC]
        tabBarController.selectedIndex = 2

        window?.rootViewController = tabBarController
        window?.makeKeyAndVisible()
    }
}
