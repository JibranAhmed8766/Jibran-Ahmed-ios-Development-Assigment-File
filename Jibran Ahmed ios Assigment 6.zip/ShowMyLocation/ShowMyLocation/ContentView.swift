import SwiftUI
import MapKit

struct ContentView: View {

    @ObservedObject private var locationManager = LocationManager()

    var body: some View {
        let coordinate = self.locationManager.location != nil
            ? self.locationManager.location!.coordinate
            : CLLocationCoordinate2D()

        return VStack {

            Text("Show My Location")
                .fontWeight(.bold)
                .font(.largeTitle)

            MapView()

            Text("Your Coordinates")
                .font(.title)
                .padding(.top, 10)

            HStack {
                Text("Latitude:")
                    .fontWeight(.bold)
                Text("\(coordinate.latitude)")
                    .fontWeight(.bold)
            }
            .foregroundColor(.blue)
            .padding(.top, 10)

            HStack {
                Text("Longitude:")
                    .fontWeight(.bold)
                Text("\(coordinate.longitude)")
                    .fontWeight(.bold)
            }
            .foregroundColor(.blue)
            .padding(.bottom, 10)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
